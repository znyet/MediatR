namespace MediatR.Internal
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal abstract class NotificationHandlerWrapper
    {
        public abstract Task HandleWait(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory);
        public abstract void HandleNoWait(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory);
        public abstract Task HandleWhenAll(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory);
        public abstract Task HandleWhenAny(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory);
    }

    internal class NotificationHandlerWrapperImpl<TNotification> : NotificationHandlerWrapper where TNotification : INotification
    {
        public override Task HandleWait(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory)
        {
            var handlers = serviceFactory
                .GetInstances<INotificationHandler<TNotification>>()
                .Select(x => new Func<Task>(() => x.Handle((TNotification)notification, cancellationToken)));

            return PublishCore(handlers);
        }

        public override void HandleNoWait(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory)
        {
            var handlers = serviceFactory
                .GetInstances<INotificationHandler<TNotification>>()
                .Select(x => new Func<Task>(() => x.Handle((TNotification)notification, cancellationToken)));

            foreach (var item in handlers)
            {
                item().ConfigureAwait(false);
            }
        }

        public override Task HandleWhenAll(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory)
        {
            var handlers = serviceFactory
                .GetInstances<INotificationHandler<TNotification>>()
                .Select(x => new Func<Task>(() => x.Handle((TNotification)notification, cancellationToken)));
            return Task.WhenAll(handlers.Select(s => s()).ToArray());
        }

        public override Task HandleWhenAny(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory)
        {
            var handlers = serviceFactory
                .GetInstances<INotificationHandler<TNotification>>()
                .Select(x => new Func<Task>(() => x.Handle((TNotification)notification, cancellationToken)));
            return Task.WhenAny(handlers.Select(s => s()).ToArray());
        }

        private async Task PublishCore(IEnumerable<Func<Task>> allHandlers)
        {
            foreach (var handler in allHandlers)
            {
                await handler().ConfigureAwait(false);
            }
        }


    }
}