namespace MediatR
{
    /// <summary>
    /// Marker interface to represent a notification
    /// </summary>
    public interface INotification { }
}