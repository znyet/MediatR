namespace MediatR.Internal
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal abstract class NotificationHandlerWrapper
    {
        public abstract Task HandleWait(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory);
        public abstract void HandleNoWait(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory);
        public abstract Task HandleWhenAll(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory);
        public abstract Task HandleWhenAny(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory);
    }

    internal class NotificationHandlerWrapperImpl<TNotification> : NotificationHandlerWrapper where TNotification : INotification
    {
        public override Task HandleWait(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory)
        {
            var handlers = serviceFactory
                .GetInstances<INotificationHandler<TNotification>>()
                .Select(x => x.Handle((TNotification)notification, cancellationToken));

            return PublishCore(handlers);
        }

        public override void HandleNoWait(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory)
        {
            var handlers = serviceFactory
                .GetInstances<INotificationHandler<TNotification>>()
                .Select(x => x.Handle((TNotification)notification, cancellationToken));

            foreach (var item in handlers)
            {
                item.ConfigureAwait(false);
            }
        }

        public override Task HandleWhenAll(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory)
        {
            var handlers = serviceFactory
                .GetInstances<INotificationHandler<TNotification>>()
                .Select(x => x.Handle((TNotification)notification, cancellationToken));
            return Task.WhenAll(handlers.ToArray());
        }

        public override Task HandleWhenAny(INotification notification, CancellationToken cancellationToken, ServiceFactory serviceFactory)
        {
            var handlers = serviceFactory
                .GetInstances<INotificationHandler<TNotification>>()
                .Select(x => x.Handle((TNotification)notification, cancellationToken));

            return Task.WhenAny(handlers.ToArray());
        }

        /// <summary>
        /// Override in a derived class to control how the tasks are awaited. By default the implementation is a foreach and await of each handler
        /// </summary>
        /// <param name="allHandlers">Enumerable of tasks representing invoking each notification handler</param>
        /// <returns>A task representing invoking all handlers</returns>
        private async Task PublishCore(IEnumerable<Task> allHandlers)
        {
            foreach (var handler in allHandlers)
            {
                await handler.ConfigureAwait(false);
            }
        }

    }
}