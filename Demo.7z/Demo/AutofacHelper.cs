﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using MediatR;
using TestMediator.ReqRes;

namespace TestMediator
{
    public class AutofacHelper
    {
        private static ContainerBuilder builder;
        private static IContainer container;
        public static void Init()
        {
            builder = new ContainerBuilder();
            
            // mediator itself
            //builder
            //  .RegisterType<Mediator>()
            //  .As<IMediator>()
            //  .InstancePerLifetimeScope();

            builder.RegisterAssemblyTypes(typeof(IMediator).GetTypeInfo().Assembly).AsImplementedInterfaces();

            // request & notification handlers
            builder.Register<ServiceFactory>(context =>
            {
                var c = context.Resolve<IComponentContext>();
                return t => c.Resolve(t);
            });

            //builder.RegisterAssemblyTypes(Assembly.GetExecutingAssembly()).Where(t => t.Name.EndsWith("Manager"));
            var assambly = Assembly.Load("TestMediator");
            builder.RegisterAssemblyTypes(assambly).AsImplementedInterfaces();

            container = builder.Build();
        }

        public static ILifetimeScope GetConn()
        {
            return container.BeginLifetimeScope();
        }
    }
}
