﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TestMediator.SubPub
{
    public class Client1 : INotificationHandler<Server>
    {
        public Task Handle(Server notification, CancellationToken cancellationToken)
        {
            return Task.Run(() =>
            {
                Console.WriteLine("client1");
            });
        }
    }
}
