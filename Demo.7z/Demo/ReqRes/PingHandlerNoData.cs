﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;

namespace TestMediator.ReqRes
{
    public class PingHandlerNoData : AsyncRequestHandler<PingNoData>
    {
        protected override Task Handle(PingNoData request, CancellationToken cancellationToken)
        {
            return Task.Run(() =>
            {
                Console.WriteLine("Pong no data");
            });
        }
    }
}
