﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestMediator.ReqRes;
using MediatR;
using Autofac;
using TestMediator.SubPub;
using System.Threading;
using System.Diagnostics;

namespace TestMediator
{
    class Program
    {
        static void Main(string[] args)
        {
            AutofacHelper.Init();

            using (var conn = AutofacHelper.GetConn())
            {
                var mediator = conn.Resolve<IMediator>();

                //Request / response
                string data = mediator.Send(new Ping()).Result;
                Console.WriteLine(data);
                mediator.Send(new PingNoData());

                Stopwatch sw = new Stopwatch();
                sw.Start();

                //Publishing / subcript
                mediator.PublishWait(new Server()); //一个完成进行下一个。直到所有都完成
                mediator.PublishNoWait(new Server()); //所有任务同步执行，不返回任何东西
                mediator.PublishWhenAll(new Server()); //所有任务同步执行，直到所有都完成
                mediator.PublishWhenAny(new Server()); //所有任务同步执行，只要有一个完成

                sw.Stop();
                Console.WriteLine(sw.ElapsedMilliseconds);


                Console.WriteLine("结束了");
            }

            Console.ReadKey();
        }
    }



}
